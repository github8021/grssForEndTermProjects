create definer = root@localhost trigger tri_hole_status
    after insert
    on sample_current
    for each row
    update hole_loc_info
set hole_loc_info.hole_loc_state = '1'
where hole_loc_info.hole_loc_id = new.hole_loc_id;

