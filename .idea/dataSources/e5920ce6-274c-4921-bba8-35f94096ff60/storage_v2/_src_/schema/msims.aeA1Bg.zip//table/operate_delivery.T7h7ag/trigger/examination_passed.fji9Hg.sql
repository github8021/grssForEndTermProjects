create definer = root@localhost trigger examination_passed
    after update
    on operate_delivery
    for each row
begin
 delete from sample_current 
 where operate_id in 
 (select operate_id from operate_delivery where new.operate_type=2);
end;

