create view box_hole_info as
select `msims`.`sample_current`.`curr_id`           AS `curr_id`,
       `msims`.`sample_current`.`sample_code`       AS `sample_code`,
       `msims`.`sample_current`.`hole_loc_id`       AS `curr_hole_loc_id`,
       `msims`.`sample_current`.`curr_volume`       AS `curr_volume`,
       `msims`.`sample_current`.`curr_unit`         AS `curr_unit`,
       `msims`.`sample_current`.`country_code`      AS `country_code`,
       `msims`.`sample_current`.`operate_id`        AS `operate_id`,
       `msims`.`sample_current`.`sample_type`       AS `sample_type`,
       `msims`.`hole_loc_info`.`hole_loc_id`        AS `hole_loc_id`,
       `msims`.`hole_loc_info`.`device_hole_loc_id` AS `device_hole_loc_id`,
       `msims`.`hole_loc_info`.`hole_loc_state`     AS `hole_loc_state`,
       `msims`.`hole_loc_info`.`hole_loc_name`      AS `hole_loc_name`
from (`msims`.`hole_loc_info`
         left join `msims`.`sample_current`
                   on ((`msims`.`hole_loc_info`.`hole_loc_id` = `msims`.`sample_current`.`hole_loc_id`)));

